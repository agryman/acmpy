#!/usr/bin/env bash
jupyter nbconvert scientific-python-and-acm.ipynb --to slides --post serve
